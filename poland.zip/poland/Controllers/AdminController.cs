﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using poland.Models;
using poland.Models.ViewModels;

namespace poland.Controllers
{
    public class AdminController : Controller
    {
        private ApplicationDbContext _context;

        public AdminController()
        {
            _context = new ApplicationDbContext();
        }

        protected override void Dispose(bool disposing)
        {
            _context.Dispose();
        }

        public ActionResult flights()
        {
            if (Session["AdminRole"] == null)
                return RedirectToAction("login", "Account");

            //DateTime dt = DateTime.Now.AddDays(1).AddHours(1);
            //var fs = _context.flights.Where(f => f.dateTime > dt).ToList();

            //for (int i = 0; i < fs.Count; i++)
            //{
            //    _context.flights.Remove(fs[i]);
            //    _context.SaveChanges();
            //}
            
            manage_fligths flight_viewmodel = new manage_fligths();

            flight_viewmodel.flights = _context.flights.ToList();

            return View(flight_viewmodel);
        }

        public ActionResult searchflight(manage_fligths manage)
        {
            if (Session["AdminRole"] == null)
                return RedirectToAction("login", "Account");

            manage_fligths flight_viewmodel = new manage_fligths();

            if (manage.flightNo != null)
            {
                int number = Int16.Parse(manage.flightNo);
                flight_viewmodel.flights = _context.flights.Where(f => f.id == number).ToList();

                flight_viewmodel.flightNo = manage.flightNo;

                return View("flights", flight_viewmodel);
            }

            else
            {
                return RedirectToAction("flights");
            }
        }

        public ActionResult filterflights(filterflight fl)
        {
            if (Session["AdminRole"] == null)
                return RedirectToAction("login", "Account");

            manage_fligths flight_viewmodel = new manage_fligths();

            if (!ModelState.IsValid)
            {
                flight_viewmodel.fl = fl;
                flight_viewmodel.flights = new List<flight>();
                return View("flights", flight_viewmodel);
            }


            flight_viewmodel.flights = _context.flights.ToList();

            for (int i = 0; i < flight_viewmodel.flights.Count; i++)
            {
                if (fl.from != null)
                {
                    if (!flight_viewmodel.flights[i].from.Trim().ToLower().Contains(fl.from.ToLower()))
                    {
                        flight_viewmodel.flights.RemoveAt(i);
                        i--;
                        continue;
                    }
                }

                if (fl.to != null)
                {
                    if (!flight_viewmodel.flights[i].to.Trim().ToLower().Contains(fl.to.Trim().ToLower()))
                    {
                        flight_viewmodel.flights.RemoveAt(i);
                        i--;
                        continue;
                    }
                }

                if (fl.airname != null)
                {
                    if (!flight_viewmodel.flights[i].airlineName.Trim().ToLower().Contains(fl.airname.ToLower()))
                    {
                        flight_viewmodel.flights.RemoveAt(i);
                        i--;
                        continue;
                    }
                }

                if (fl.min != null)
                {
                    if (flight_viewmodel.flights[i].price < decimal.Parse(fl.min))
                    {
                        flight_viewmodel.flights.RemoveAt(i);
                        i--;
                        continue;
                    }
                }

                if (fl.max != null)
                {
                    if (flight_viewmodel.flights[i].price > decimal.Parse(fl.max))
                    {
                        flight_viewmodel.flights.RemoveAt(i);
                        i--;
                        continue;
                    }
                }

                if (fl.date != null)
                {
                    List<string> infliter = new List<string>();
                    infliter = fl.date.Split('-').ToList();

                    string year1 = infliter[0], month1 = infliter[1], day1 = infliter[2];

                    List<string> indb = new List<string>();
                    indb = flight_viewmodel.flights[i].dateTime.ToString().Split('/').ToList();

                    string year2 = indb[0], month2 = indb[1], day2;

                    List<string> daytime = new List<string>();
                    daytime = indb[2].Split(' ').ToList();
                    day2 = daytime[0];

                    if (Int16.Parse(year1) > Int16.Parse(year2))
                    {
                        flight_viewmodel.flights.RemoveAt(i);
                        i--;
                        continue;
                    }

                    else if (Int16.Parse(year1) == Int16.Parse(year2) && Int16.Parse(month1) > Int16.Parse(month2))
                    {
                        flight_viewmodel.flights.RemoveAt(i);
                        i--;
                        continue;
                    }

                    else if (Int16.Parse(year1) == Int16.Parse(year2) && Int16.Parse(month1) == Int16.Parse(month2) && Int16.Parse(day1) > Int16.Parse(day2))
                    {
                        flight_viewmodel.flights.RemoveAt(i);
                        i--;
                        continue;
                    }

                }

            }

            flight_viewmodel.fl = fl;
            return View("flights", flight_viewmodel);

        }

        public ActionResult ViewDeleteFlight(string flightId)
        {
            if (Session["AdminRole"] == null)
                return RedirectToAction("login", "Account");

            int fId = Int16.Parse(flightId);
            var flight = (flight) _context.flights.SingleOrDefault(f => f.id == fId);
            return View("DeleteFlight",flight);
        }

        public ActionResult ViewEditFlight(string flightId)
        {
            if (Session["AdminRole"] == null)
                return RedirectToAction("login", "Account");

            int fId = Int16.Parse(flightId);
            var flightInDb = (flight)_context.flights.SingleOrDefault(f => f.id == fId);

            ManageFlight flight = new ManageFlight();
            flight.airlineName = flightInDb.airlineName;
            flight.datetime = flightInDb.dateTime.ToString();
            flight.duration = flightInDb.duration;
            flight.from = flightInDb.from;
            flight.to = flightInDb.to;
            flight.price = flightInDb.price;
            flight.id = flightInDb.id;

            return View("EditFlight",flight);
        }

        public ActionResult DeleteFlight(flight f)
        {
            if (Session["AdminRole"] == null)
                return RedirectToAction("login", "Account");
            
            var SelectFlight = (flight)_context.flights.Find(f.id);

            _context.flights.Remove(SelectFlight);
            _context.SaveChanges();

            manage_fligths manage_f = new manage_fligths();
            manage_f.flights = _context.flights.ToList();

            return View("flights",manage_f);
        }

        public ActionResult EditFlight(ManageFlight f)
        {
            if (Session["AdminRole"] == null)
                return RedirectToAction("login", "Account");

            if (!ModelState.IsValid)
            {
                return View(f);
            }

            var flightInDb = (flight) _context.flights.SingleOrDefault(flight => flight.id == f.id);

            flightInDb.from = f.from;
            flightInDb.to = f.to;
            flightInDb.price = f.price;
            flightInDb.duration = f.duration;
            flightInDb.dateTime = DateTime.Parse(f.datetime);
            flightInDb.airlineName = f.airlineName;

            _context.SaveChanges();
            
            return RedirectToAction("flights");
        }

        public ActionResult AddFlight(manage_fligths f)
        {
            if (Session["AdminRole"] == null)
                return RedirectToAction("login", "Account");

            if (!ModelState.IsValid)
            {
                f.flights = _context.flights.ToList();
                return View("flights", f);
            }

            flight CustingFlight = new flight();

            CustingFlight.airlineName = f.flight.airlineName;
            CustingFlight.duration = f.flight.duration;
            CustingFlight.from = f.flight.from;
            CustingFlight.to = f.flight.to;
            CustingFlight.price = f.flight.price;
            CustingFlight.dateTime = DateTime.Parse(f.flight.datetime);
            
            _context.flights.Add(CustingFlight);
            _context.SaveChanges();

            return RedirectToAction("flights");
        }

        public ActionResult places()
        {
            if (Session["AdminRole"] == null)
                return RedirectToAction("login", "Account");

            manage_places manage_p = new manage_places();
            manage_p.places = _context.Places.ToList();
            
            return View(manage_p);
        }

        public ActionResult AddPlace(manage_places p)
        {
            if (Session["AdminRole"] == null)
                return RedirectToAction("login", "Account");

            if (!ModelState.IsValid)
            {
                p.places = _context.Places.ToList();
                return View("places",p);
            }

            Place place = new Place();
            place.PhotoURL = p.place.PhotoURL;
            place.name = p.place.name.ToLower();
            place.paragraph = p.place.paragraph;

            _context.Places.Add(place);
            _context.SaveChanges();
            
            manage_places manage_p = new manage_places();
            manage_p.places = _context.Places.ToList();
            
            return RedirectToAction("places");
        }

        public ActionResult searchPlace(manage_places manage)
        {
            if (Session["AdminRole"] == null)
                return RedirectToAction("login", "Account");

            manage_places manage_p = new manage_places();
            manage_p.searchName = manage.searchName;
            manage_p.places = _context.Places.Where(place => place.name.Contains(manage.searchName.Trim().ToLower())).ToList();

            return View("places", manage_p);
        }

        public ActionResult DeletePlaceView(Place p)
        {
            if (Session["AdminRole"] == null)
                return RedirectToAction("login", "Account");

            return View("DeletePlace",p);
        }

        public ActionResult DeletePlace(Place p)
        {
            if (Session["AdminRole"] == null)
                return RedirectToAction("login", "Account");

            var deletedPlace = (Place)_context.Places.Find(p.id);

            _context.Places.Remove(deletedPlace);
            _context.SaveChanges();

            return RedirectToAction("places");
        }

        public ActionResult EditPlaceView(Place p)
        {
            return View("EditPlace",p);
        }

        public ActionResult EditPlace(Place p)
        {
            if (!ModelState.IsValid)
            {
                return View(p);
            }

            var place = (Place) _context.Places.Find(p.id);

            place.name = p.name;
            place.paragraph = p.paragraph;
            place.PhotoURL = p.PhotoURL;
            _context.SaveChanges();

            return RedirectToAction("places");
        }

        public ActionResult viewOffers(string placeName)
        {
            filterflight fl = new filterflight();
            fl.to = placeName;
            return RedirectToAction("filterflights",fl);
        }
    }
}



