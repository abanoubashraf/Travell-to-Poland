﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Web;
using System.Web.Mvc;
using poland.Models;
using poland.Models.ViewModels;

namespace poland.Controllers
{
    public class travellController : Controller
    {
        // GET: places
        private ApplicationDbContext _context;

        public travellController()
        {
            _context = new ApplicationDbContext();
        }

        protected override void Dispose(bool disposing)
        {
            _context.Dispose();
        }
        public ActionResult places()
        {
            manage_places viewmodel = new manage_places();
            viewmodel.places = _context.Places.ToList();

            return View(viewmodel);
        }

        public ActionResult flights()
        {
            DateTime dt = DateTime.Now.AddDays(1).AddHours(1);
            var fs = _context.flights.Where(f => f.dateTime < dt).ToList();

            for (int i = 0; i < fs.Count; i++)
            {
                _context.flights.Remove(fs[i]);
                _context.SaveChanges();
            }

            fs = _context.flights.ToList();

            flights_page viewmodel = new flights_page();
            viewmodel.fs = fs;


            if (Session["p_id"] != null)
            {
                int pid = (int) Session["p_id"];
                viewmodel.tickets = _context.tickets.Where(t => t.passengerid == pid).ToList();
            }

            return View(viewmodel);
        }

        public ActionResult searchflight(flights_page f)
        {
            flights_page viewmodel = new flights_page();

            if (f.flightNo != null || f.flightNo == "")
            {
                int number = Int16.Parse(f.flightNo);
                viewmodel.fs = _context.flights.Where(flight => flight.id == number).ToList();

                viewmodel.tickets = null;

                if (Session["p_id"] != null)
                {
                    int p_id = Int16.Parse(Session["p_id"].ToString());
                    viewmodel.tickets = (List<ticket>)_context.tickets.Where(t => t.passengerid == p_id).ToList();
                }
            }
            else
            {
                viewmodel.fs = _context.flights.ToList();
                viewmodel.tickets = _context.tickets.ToList();
            }

            viewmodel.flightNo = f.flightNo;

            return View("flights",viewmodel);
        }

        public ActionResult filterflights(filterflight fl)
        {
            flights_page viewmodel = new flights_page();

            if (!ModelState.IsValid)
            {
                viewmodel.fl = fl;
                viewmodel.fs = new List<flight>();
                viewmodel.tickets = _context.tickets.ToList();
                return View("flights", viewmodel);
            }


            var flights = _context.flights.ToList();

            for (int i = 0; i < flights.Count; i++)
            {
                if (fl.from != null)
                {
                    if (!flights[i].from.Trim().ToLower().Contains(fl.from.ToLower()))
                    {
                        flights.RemoveAt(i);
                        i--;
                        continue;
                    }
                }

                if (fl.to != null)
                {
                    if (!flights[i].to.Trim().ToLower().Contains(fl.to.Trim().ToLower()))
                    {
                        flights.RemoveAt(i);
                        i--;
                        continue;
                    }
                }

                if (fl.airname != null)
                {
                    if (!flights[i].airlineName.Trim().ToLower().Contains(fl.airname.ToLower()))
                    {
                        flights.RemoveAt(i);
                        i--;
                        continue;
                    }
                }

                if (fl.min != null)
                {
                    if (flights[i].price < decimal.Parse(fl.min))
                    {
                        flights.RemoveAt(i);
                        i--;
                        continue;
                    }
                }

                if (fl.max != null)
                {
                    if (flights[i].price > decimal.Parse(fl.max))
                    {
                        flights.RemoveAt(i);
                        i--;
                        continue;
                    }
                }

                if (fl.date != null)
                {
                    List<string> infliter = new List<string>();
                    infliter = fl.date.Split('-').ToList();

                    string year1 = infliter[0] , month1 = infliter[1] , day1 = infliter[2];

                    List<string> indb = new List<string>();
                    indb = flights[i].dateTime.ToString().Split('/').ToList();

                    string day2 = indb[1] , month2 = indb[0] , year2 ;

                    List<string> yeartime = new List<string>();
                    yeartime = indb[2].Split(' ').ToList();
                    year2 = yeartime[0];

                    if(Int16.Parse(year1) > Int16.Parse(year2))
                    {
                        flights.RemoveAt(i);
                        i--;
                        continue;
                    }

                    else if (Int16.Parse(year1) == Int16.Parse(year2) && Int16.Parse(month1) > Int16.Parse(month2))
                    {
                        flights.RemoveAt(i);
                        i--;
                        continue;
                    }

                    else if (Int16.Parse(year1) == Int16.Parse(year2) && Int16.Parse(month1) == Int16.Parse(month2) && Int16.Parse(day1) > Int16.Parse(day2))
                    {
                        flights.RemoveAt(i);
                        i--;
                        continue;
                    }

                }

            }

            viewmodel.fl = fl;
            viewmodel.fs = flights;
            viewmodel.tickets = _context.tickets.ToList();

            return View("flights",viewmodel);

        }

        public ActionResult reserve(int f_id)
        {
            if (Session["p_id"] == null)
                return RedirectToAction("login", "Account");

            ticket t = new ticket();
            t.passengerid = (int)Session["p_id"];
            t.flightid = f_id;

            _context.tickets.Add(t);
            _context.SaveChanges();

            return RedirectToAction("flights");
        }

        public ActionResult SearchPlace(manage_places m)
        {
            manage_places viewmodel = new manage_places();
            if (m.searchName != "" & m.searchName != null)
                viewmodel.places = _context.Places.Where(p => p.name.Contains(m.searchName.Trim().ToLower())).ToList();
            else
                viewmodel.places = _context.Places.ToList();

            viewmodel.searchName = m.searchName;

            return View("places",viewmodel);
        }

        public ActionResult viewOffers(string placeName)
        {
            filterflight fl = new filterflight();
            fl.to = placeName;
            return RedirectToAction("filterflights", fl);
        }
    }
}







