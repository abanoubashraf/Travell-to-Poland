﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using poland.Models;
using poland.Controllers;

namespace poland.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account

        private ApplicationDbContext _context;

        public AccountController()
        {
            _context = new ApplicationDbContext();
        }
        protected override void Dispose(bool disposing)
        {
            _context.Dispose();
        }
        public ActionResult createAcc()
        {
            return View();
        }
        [HttpPost]
        public ActionResult addAcc(PassengerRegistration pas)
        {
            Passenger p = new Passenger();
            p.name = pas.name;
            p.email = pas.email;
            p.password = pas.password;

            if (!ModelState.IsValid)
                return View("createAcc", pas);

            else
            {
                Login login = new Login();
                login.email = pas.email;
                login.password = pas.password;

                _context.passengers.Add(p);
                _context.SaveChanges();

                return RedirectToAction("login", "Account");
            }
        }

        public ActionResult login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CheckLogin(Login login)
        {
            if (login.AdminRole == null)
            {
                if (!ModelState.IsValid)
                {
                    return View("login", login);
                }

                Passenger passenger = new Passenger();
                passenger = (Passenger)_context.passengers.SingleOrDefault(p => p.email == login.email);

                Session["Admin_name"] = null;
                Session["AdminRole"] = null;
                Session["p_id"] = passenger.id;
                Session["p_name"] = passenger.name;
                Session["p_email"] = passenger.email;

                return RedirectToAction("Index", "Home");
            }
            else
            {
                if (!ModelState.IsValid)
                {
                    return View("login", login);
                }

                Admin admin = new Admin();
                admin = (Admin)_context.admins.SingleOrDefault(p => p.email == login.email);

                Session["Admin_name"] = admin.name;
                Session["AdminRole"] = "on";
                Session["p_id"] = admin.id;
                Session["p_name"] = admin.name;
                Session["p_email"] = admin.email;

                return RedirectToAction("flights", "Admin", login);
            }
        }

        public ActionResult logout()
        {
            Session["AdminRole"] = null;
            Session["p_id"] = null;
            Session["p_name"] = null;
            Session["p_email"] = null;

            return RedirectToAction("login", "Account");
        }

    }
}