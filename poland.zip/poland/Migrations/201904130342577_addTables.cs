namespace poland.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class addTables : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Admins",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        email = c.String(),
                        name = c.String(),
                        password = c.String(),
                    })
                .PrimaryKey(t => t.id);
            
            CreateTable(
                "dbo.flights",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        from = c.String(),
                        to = c.String(),
                        duration = c.Int(nullable: false),
                        airlineName = c.String(),
                        dateTime = c.DateTime(nullable: false),
                        price = c.Decimal(nullable: false, precision: 18, scale: 2),
                    })
                .PrimaryKey(t => t.id);
            
            CreateTable(
                "dbo.Passengers",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        name = c.String(nullable: false, maxLength: 30),
                        password = c.String(nullable: false, maxLength: 50),
                        email = c.String(nullable: false, maxLength: 50),
                    })
                .PrimaryKey(t => t.id);
            
            CreateTable(
                "dbo.Places",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        name = c.String(nullable: false, maxLength: 20),
                        paragraph = c.String(nullable: false),
                        PhotoURL = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.id);
            
            CreateTable(
                "dbo.tickets",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        flightid = c.Int(nullable: false),
                        passengerid = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.id)
                .ForeignKey("dbo.flights", t => t.flightid, cascadeDelete: true)
                .ForeignKey("dbo.Passengers", t => t.passengerid, cascadeDelete: true)
                .Index(t => t.flightid)
                .Index(t => t.passengerid);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.tickets", "passengerid", "dbo.Passengers");
            DropForeignKey("dbo.tickets", "flightid", "dbo.flights");
            DropIndex("dbo.tickets", new[] { "passengerid" });
            DropIndex("dbo.tickets", new[] { "flightid" });
            DropTable("dbo.tickets");
            DropTable("dbo.Places");
            DropTable("dbo.Passengers");
            DropTable("dbo.flights");
            DropTable("dbo.Admins");
        }
    }
}
