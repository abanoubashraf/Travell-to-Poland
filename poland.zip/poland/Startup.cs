﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(poland.Startup))]
namespace poland
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
