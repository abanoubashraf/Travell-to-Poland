﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace poland.Models.ViewModels
{
    public class manage_places
    {
        public List<Place> places { get; set; }

        public Place place { get; set; }

        public string searchName { get; set; }

    }
}