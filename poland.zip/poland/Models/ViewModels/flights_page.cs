﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace poland.Models.ViewModels
{
    public class flights_page
    {
        public filterflight fl { get; set; }

        public List<flight> fs { get; set; }

        public List<ticket> tickets { get; set; }

        public string flightNo { get; set; }
    }
}