﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace poland.Models.ViewModels
{
    public class manage_fligths
    {
        public ManageFlight flight { get; set; }

        public List<flight> flights { get; set; }

        public filterflight fl { get; set; }

        public string flightNo { get; set; }
    }
}