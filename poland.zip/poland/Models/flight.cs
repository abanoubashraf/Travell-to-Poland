﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using poland.Models.CustomValidation;

namespace poland.Models
{
    public class flight
    {
        public int id { get; set; }

        public string from { get; set; }

        public string to { get; set; }

        public int duration { get; set; }

        public string airlineName { get; set; }

        public DateTime dateTime { get; set; }

        public decimal price { get; set; }
    }
    public class ManageFlight
    {
        public int id { get; set; }

        [Required]
        public string from { get; set; }

        [Required]
        public string to { get; set; }

        [durationPositiveValue]
        [Required]
        public int duration { get; set; }

        [Required]
        public string airlineName { get; set; }

        [LargerDate]
        [Required]
        public string datetime { get; set; }

        [pricePositiveValue]
        [Required]
        public decimal price { get; set; }
    }
}