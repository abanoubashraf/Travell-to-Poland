﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace poland.Models
{
    public class Place
    {
        public int id { get; set; }
        [Required]
        [StringLength(20)]
        public string name { get; set; }

        [Required]
        public string paragraph { get; set; }

        [Required]
        public string PhotoURL { get; set; }
    }
}