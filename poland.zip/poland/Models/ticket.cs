﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace poland.Models
{
    public class ticket
    {
        public int id { get; set; }
        public Passenger passenger{ get; set; }
        public flight flight { get; set; }

        public int flightid { get; set; }

        public int passengerid { get; set; }
    }
}