﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace poland.Models
{
    public class PassengerData
    {
        public Passenger passenger { get; set; }
        public List<ticket> tickets { get; set; }
    }
}