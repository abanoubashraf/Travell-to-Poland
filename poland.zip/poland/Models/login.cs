﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using poland.Models.CustomValidation;

namespace poland.Models
{
    public class Login
    {
        [Required]
        [RightPassword]
        [StringLength(50)]
        [DataType(DataType.Password)]
        public string password { get; set; }

        [Required]
        [StringLength(50)]
        [EmailAddress]
        [EmailLogin]
        [Display(Name = "e-mail")]
        public string email { get; set; }

        public string AdminRole { get; set; }
    }
}