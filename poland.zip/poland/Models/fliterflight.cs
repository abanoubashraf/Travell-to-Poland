﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using poland.Models.CustomValidation;

namespace poland.Models
{
    public class filterflight
    {
        public string from { get; set; }

        public string to { get; set; }

        public string airname { get; set; }

        public string date { get; set; }

        [min_filterflight]
        public string min { get; set; }

        [max_filterflight]
        public string max { get; set; }
    }
}