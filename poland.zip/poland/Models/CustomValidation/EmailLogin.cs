﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace poland.Models.CustomValidation
{
    public class EmailLogin : ValidationAttribute
    {
        private ApplicationDbContext _context;

        public EmailLogin()
        {
            _context = new ApplicationDbContext();
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var mypassenger = (Login)validationContext.ObjectInstance;


            if (mypassenger.AdminRole == null)
            {
                var LogicPassenger = (Passenger) _context.passengers.SingleOrDefault(p => p.email == mypassenger.email);

                if (LogicPassenger == null)
                {
                    return new ValidationResult("There is no account with this e-mail");
                }
            }

            else if(mypassenger.AdminRole == "on")
            {
                var LogicAdmin = (Admin)_context.admins.SingleOrDefault(a => a.email == mypassenger.email);

                if (LogicAdmin == null)
                {
                    return new ValidationResult("There is no account with this e-mail");
                }
            }

            return ValidationResult.Success;
        }
    }
}