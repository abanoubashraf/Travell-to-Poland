﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using poland.Models.ViewModels;

namespace poland.Models.CustomValidation
{
    public class pricePositiveValue : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            ManageFlight f = (ManageFlight)validationContext.ObjectInstance;

            if (f.price < 1)
            {
                return new ValidationResult("you can`t insert a negative value or zero");
            }

            return ValidationResult.Success;
        }
    }
}