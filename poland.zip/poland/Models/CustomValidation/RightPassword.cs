﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace poland.Models.CustomValidation
{
    public class RightPassword : ValidationAttribute
    {
        private ApplicationDbContext _context;
        public RightPassword()
        {
            _context = new ApplicationDbContext();
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var mypassenger = (Login)validationContext.ObjectInstance;

            if (mypassenger.AdminRole == null)
            {
                var LogicPassenger = (Passenger) _context.passengers.SingleOrDefault(p => p.email == mypassenger.email);

                if (LogicPassenger == null)
                    return ValidationResult.Success;

                if (LogicPassenger.password != mypassenger.password)
                    return new ValidationResult("Wrong password");
            }

            else if (mypassenger.AdminRole == "on")
            {
                var LogicAdmin = (Admin)_context.admins.SingleOrDefault(a => a.email == mypassenger.email);

                if (LogicAdmin == null)
                    return ValidationResult.Success;

                if (LogicAdmin.password != mypassenger.password)
                    return new ValidationResult("Wrong password");
            }

            return ValidationResult.Success;
        }
    }
}