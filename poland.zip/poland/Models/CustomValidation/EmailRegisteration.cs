﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace poland.Models.CustomValidation
{
    public class EmailRegisteration : ValidationAttribute
    {
        private ApplicationDbContext _context;
        public EmailRegisteration()
        {
            _context = new ApplicationDbContext();
        }
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var mypassenger = (PassengerRegistration) validationContext.ObjectInstance;

            var LogicPassenger = (Passenger)_context.passengers.SingleOrDefault( p => p.email == mypassenger.email);
            
            if (LogicPassenger != null)
            {
                return new ValidationResult("This e-mail is allready registrated");
            }

            return ValidationResult.Success;
        }
    }
}   