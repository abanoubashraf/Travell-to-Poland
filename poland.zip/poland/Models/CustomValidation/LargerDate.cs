﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;
using poland.Models.ViewModels;

namespace poland.Models.CustomValidation
{
    public class LargerDate : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            ManageFlight f = (ManageFlight)validationContext.ObjectInstance;

            DateTime datetimeNeeded = DateTime.Now.AddDays(2);
            try
            {
                if (DateTime.Parse(f.datetime) < datetimeNeeded)
                {
                    return new ValidationResult("you can`t add a day earlier than 2 days from now");
                }
            }
            catch (Exception e)
            {
                return new ValidationResult("you must use right format ex : " + DateTime.Now.ToString());
            }
            

            return ValidationResult.Success;
        }
    }
}