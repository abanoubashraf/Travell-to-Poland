﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace poland.Models.CustomValidation
{
    public class min_filterflight : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var filter = (Models.filterflight)validationContext.ObjectInstance;

            if (filter.max != null && filter.min != null)
                if (double.Parse(filter.min) > double.Parse(filter.max))
                    return new ValidationResult("");

            return ValidationResult.Success;
        }
    }
    public class max_filterflight : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var filter = (Models.filterflight)validationContext.ObjectInstance;
            
            if (filter.max != null && filter.min != null)
                if (double.Parse(filter.min) > double.Parse(filter.max))
                    return new ValidationResult("");

            return ValidationResult.Success;
        }
    }

    public class date_filterflight : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var filter = (Models.filterflight)validationContext.ObjectInstance;
            DateTime dt = DateTime.Now;
            //dt.Date.ToString().
            //if()
            return ValidationResult.Success;
        }
    }
}